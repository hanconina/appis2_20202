package principles.ocp.products.solution;

public enum SEMESTRE {
    I, II, III, IV, V    
}
