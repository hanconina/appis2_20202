
package principles.ocp.products.solution;

public class AndEspecificacion <T> implements Especificacion<T>{
    private Especificacion<T> primero, segundo;

    public AndEspecificacion(Especificacion<T> primero, Especificacion<T> segundo) {
        this.primero = primero;
        this.segundo = segundo;
    }

    @Override
    public boolean estaSatisfecho(T item) {
        return primero.estaSatisfecho(item) && segundo.estaSatisfecho(item);
    }

    
    
}
