package principles.ocp.products.solution;

import java.util.ArrayList;
import java.util.List;

public class MejorFiltro implements Filtrar<Alumno> {

    @Override
    public List<Alumno> filtrar(List<Alumno> items, Especificacion<Alumno> esp) {
        List<Alumno> aux = new ArrayList<Alumno>();
        for (Alumno a : items){
            if (esp.estaSatisfecho(a))
                aux.add(a);
        }
        return aux;
    }
    
}
