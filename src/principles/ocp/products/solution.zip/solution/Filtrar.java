
package principles.ocp.products.solution;

import java.util.List;

public interface Filtrar <T>{
    List<T> filtrar(List<T> items, Especificacion<T> esp);        
}
