package principles.ocp.products.solution;

public interface Especificacion<T> {
    boolean estaSatisfecho(T item);
}
