package principles.ocp.products.solution;

public enum CARRERA {
    IS, II, IC
}
