package principles.ocp.products.solution;

public class EspecificacionSemestre implements Especificacion<Alumno>{
    private SEMESTRE semestre;

    public EspecificacionSemestre(SEMESTRE semestre) {
        this.semestre = semestre;
    }
    @Override
    public boolean estaSatisfecho(Alumno item) {
        return item.semestreActual == semestre;        
    }
    
    
}
